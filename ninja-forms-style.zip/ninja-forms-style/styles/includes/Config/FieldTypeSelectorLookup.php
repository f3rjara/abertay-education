<?php

return array(
    'wrap' => '.field-wrap',
    'label' => '.nf-field-label label',
    'element' => '.nf-field-element .ninja-forms-field',
);
